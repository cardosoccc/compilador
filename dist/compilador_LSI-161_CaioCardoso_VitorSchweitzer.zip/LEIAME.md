# Compilador LSI-161

Alunos:
- Caio Cargnin Cardoso
- Vítor Schweitzer

Para rodar o programa execute:

```
java -jar dist/compilador_LSI-161_CaioCardoso_VitorSchweitzer.jar
```


A especificação léxica encontra-se em `lexico.gals`.  
A especificação léxica + sintática encontra-se em `lexico_sintatico.gals`.   
O programa teste encontra-se em `programaTeste.txt`.  

*19/07/2016*
